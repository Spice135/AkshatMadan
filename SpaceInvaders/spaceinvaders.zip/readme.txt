Akshat Madan - Space Invaders (GameMaker)
A recreation of the classic Space Invaders game made in GameMaker

Controls:
Left arrow 	: Move Left
Right arrow 	: Move Right
Spacebar 	: Fire Projectile

Instructions:
Shoot and destroy all 55 aliens on the screen.
The 4 green barriers are there to protect you, they can be destroyed by alien projectiles or your own.
You have 3 lives, if an alien projectile touches you, you will lose 1 life.
The aliens speed up as they come closer to you.
If an alien touches you, you lose all remaining lives.
If you kill all aliens in one screen, the room resets and a new wave of 55 aliens appears.
Good Luck!

Known bugs or glitches:
There are no knows bugs or glitches in the game.

This version of the game has no cheats.


* * * Created by Akshat Madan * * *